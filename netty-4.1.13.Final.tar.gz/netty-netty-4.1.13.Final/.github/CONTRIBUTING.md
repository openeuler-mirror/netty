Please review the [guidelines for contributing](http://netty.io/wiki/developer-guide.html) for this repository.
